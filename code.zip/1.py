import pandas as pd

file_path = 'D:/github/UMT/UMT/data/svg/test.txt'

# 定义有效标签
valid_labels = ["O", "B-MISC", "I-MISC", "B-PER", "I-PER", "B-ORG", "I-ORG", "B-LOC", "I-LOC", "B-OTHER", "I-OTHER", "X", "[CLS]", "[SEP]"]

data = pd.read_csv(file_path, sep='\s+', header=None, names=["word", "label"], skip_blank_lines=True)

print("数据文件的列名：", data.columns.tolist())

print("数据文件的前几行：")
print(data.head(10))

nan_rows = data[data['label'].isna()]

if not nan_rows.empty:
    print("包含 nan 标签的行：")
    print(nan_rows)
else:
    print("没有包含 nan 标签的行。")

labels = data['label'].dropna().unique()

print("所有标签：", labels)

invalid_labels = [label for label in labels if label not in valid_labels]
if invalid_labels:
    print("无效标签：", invalid_labels)
else:
    print("所有标签均为有效标签。")

